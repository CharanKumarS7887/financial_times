# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class FinancialtimeItem(scrapy.Item):
    # define the fields for your item here like:
    date_posted = scrapy.Field()
    image_url = scrapy.Field()
    is_special = scrapy.Field()
    published_by = scrapy.Field()
    title = scrapy.Field()
    description = scrapy.Field()
